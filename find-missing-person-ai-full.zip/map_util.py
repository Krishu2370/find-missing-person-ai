
import webbrowser

def open_map(location):
    query = location.replace(" ", "+")
    url = f"https://www.google.com/maps/search/?api=1&query={query}"
    webbrowser.open(url)
