
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument("--headless")
driver = webdriver.Chrome(options=options)

driver.get("https://www.example.com/cctv")
images = driver.find_elements_by_tag_name("img")
for img in images:
    src = img.get_attribute("src")
    print(src)
driver.quit()
