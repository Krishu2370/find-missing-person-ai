
import cv2
import os

name = input("Enter person's name: ")
folder = f"dataset/{name}"
os.makedirs(folder, exist_ok=True)

cap = cv2.VideoCapture(0)
count = 0

while count < 20:
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imshow("Collecting Faces", frame)
    cv2.imwrite(f"{folder}/{count}.jpg", frame)
    count += 1
    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
