
import face_recognition
import os
import pickle

known_encodings = []
known_names = []

for person in os.listdir("dataset"):
    for image_name in os.listdir(f"dataset/{person}"):
        image_path = f"dataset/{person}/{image_name}"
        image = face_recognition.load_image_file(image_path)
        encoding = face_recognition.face_encodings(image)
        if encoding:
            known_encodings.append(encoding[0])
            known_names.append(person)

data = {"encodings": known_encodings, "names": known_names}
with open("encodings.pickle", "wb") as f:
    pickle.dump(data, f)
