
from flask import Flask, request, render_template
import face_recognition
import cv2
import numpy as np
import pickle
import os
from upload_to_firebase import upload_data
from map_util import open_map

app = Flask(__name__)

# Load encodings
with open("encodings.pickle", "rb") as f:
    data = pickle.load(f)

@app.route("/", methods=["GET", "POST"])
def index():
    message = ""
    if request.method == "POST":
        file = request.files["image"]
        location = request.form["location"]
        img_path = "static/uploaded.jpg"
        file.save(img_path)

        image = face_recognition.load_image_file(img_path)
        encoding = face_recognition.face_encodings(image)
        if encoding:
            matches = face_recognition.compare_faces(data["encodings"], encoding[0])
            name = "Unknown"

            if True in matches:
                matchedIdxs = [i for (i, b) in enumerate(matches) if b]
                counts = {}
                for i in matchedIdxs:
                    name = data["names"][i]
                    counts[name] = counts.get(name, 0) + 1
                name = max(counts, key=counts.get)
                upload_data(name, location)
                open_map(location)
                message = f"Match found: {name}. Location saved."
            else:
                message = "No match found."

    return render_template("index.html", message=message)

if __name__ == "__main__":
    app.run(debug=True)
