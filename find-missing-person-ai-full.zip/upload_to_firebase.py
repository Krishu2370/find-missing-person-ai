
import firebase_admin
from firebase_admin import credentials, firestore

cred = credentials.Certificate("firebase_key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

def upload_data(name, location):
    doc_ref = db.collection("missing_people").document(name)
    doc_ref.set({
        "last_seen": location
    })
